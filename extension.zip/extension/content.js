// ═══════════════════════════════════════════════════════════════════════════════
// Therapheye Extension – Content Script
// Reads accessibility settings AND user data from the therapeye page's
// localStorage and syncs them to chrome.storage.local so the popup/background
// can use them.
// ═══════════════════════════════════════════════════════════════════════════════

const A11Y_KEY = 'therapeye_accessibility_settings';
const USER_KEY = 'therapeye_user';
const SESSION_KEY = 'therapeye_session_token';

// ── Sync accessibility settings ──────────────────────────────────────────────

function syncA11ySettings() {
  try {
    const raw = localStorage.getItem(A11Y_KEY);
    if (raw) {
      const settings = JSON.parse(raw);
      chrome.storage.local.set({ therapeye_a11y_settings: settings });
    } else {
      chrome.storage.local.remove('therapeye_a11y_settings');
    }
  } catch (e) {
    console.warn('[Therapheye Content] Error syncing a11y settings:', e);
  }
}

// ── Sync user data ───────────────────────────────────────────────────────────

function syncUserData() {
  try {
    const raw = localStorage.getItem(USER_KEY);
    if (raw) {
      const user = JSON.parse(raw);
      chrome.storage.local.set({ therapeye_user: user });
    } else {
      // User logged out → remove from extension storage
      chrome.storage.local.remove('therapeye_user');
    }
  } catch (e) {
    console.warn('[Therapheye Content] Error syncing user data:', e);
  }
}

function syncSessionToken() {
  try {
    const token = localStorage.getItem(SESSION_KEY);
    if (token) {
      chrome.storage.local.set({ therapeye_session_token: token });
    } else {
      chrome.storage.local.remove('therapeye_session_token');
    }
  } catch (e) {
    console.warn('[Therapheye Content] Error syncing session token:', e);
  }
}

// ── Sync everything on page load ─────────────────────────────────────────────

syncA11ySettings();
syncUserData();
syncSessionToken();

// ── Listen for localStorage changes ─────────────────────────────────────────

window.addEventListener('storage', (e) => {
  if (e.key === A11Y_KEY) syncA11ySettings();
  if (e.key === USER_KEY) syncUserData();
  if (e.key === SESSION_KEY) syncSessionToken();
});

// ── Periodic sync (catches programmatic localStorage writes in same tab) ────
setInterval(() => {
  syncUserData();
  syncSessionToken();
}, 3000);
