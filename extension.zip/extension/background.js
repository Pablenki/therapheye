// ═══════════════════════════════════════════════════════════════════════════════
// Therapheye Extension – Background Service Worker
// Detects user activity across ALL browser tabs, manages screen time timer,
// inactivity alerts, and break reminders (20-20-20 rule).
// ═══════════════════════════════════════════════════════════════════════════════

const WORK_MINUTES        = 20;       // Break every 20 min
const INACTIVITY_MINUTES  = 5;        // Pause after 5 min of no activity
const WARN_BEFORE_PAUSE_S = 120;      // 2 min of beeping before auto-pause
const TICK_INTERVAL_MS    = 1000;     // 1-second tick
const STORAGE_KEY         = 'therapeye_ext_timer';

// ─── State ────────────────────────────────────────────────────────────────────

let state = {
  isRunning: false,
  accumulatedMs: 0,
  startTimestamp: null,          // Date.now() when last started
  sessionStartTimestamp: null,   // When the overall session began
  nextBreakAtMs: null,           // Accumulated ms when next break fires
  finalized: false,
  stateDate: todayDate(),
  // Inactivity tracking
  lastActivityTs: Date.now(),    // Last time user did ANYTHING in the browser
  inactivityWarning: false,      // Currently in the "beeping" warning phase
  inactivityWarnStartTs: null,   // When the warning phase started
};

let tickInterval = null;

// ─── Helpers ──────────────────────────────────────────────────────────────────

function todayDate() {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
}

function calcElapsedMs() {
  let ms = state.accumulatedMs;
  if (state.isRunning && state.startTimestamp) {
    const delta = Date.now() - state.startTimestamp;
    if (delta > 0 && delta < 16 * 3600000) ms += delta;
  }
  return Math.max(0, ms);
}

function formatDuration(totalMs) {
  const totalSec = Math.floor(totalMs / 1000);
  const h = Math.floor(totalSec / 3600);
  const m = Math.floor((totalSec % 3600) / 60);
  const s = totalSec % 60;
  const pad = n => n.toString().padStart(2, '0');
  return `${pad(h)}:${pad(m)}:${pad(s)}`;
}

// ─── Persistence (chrome.storage.local) ───────────────────────────────────────

async function saveState() {
  try {
    await chrome.storage.local.set({ [STORAGE_KEY]: state });
  } catch (e) {
    console.warn('[Therapheye BG] Error saving state:', e);
  }
}

async function loadState() {
  try {
    const result = await chrome.storage.local.get(STORAGE_KEY);
    if (result[STORAGE_KEY]) {
      const saved = result[STORAGE_KEY];
      // Day change detection
      if (saved.stateDate !== todayDate()) {
        // New day → reset
        state = { ...state, accumulatedMs: 0, startTimestamp: null, isRunning: false, sessionStartTimestamp: null, nextBreakAtMs: null, finalized: false, stateDate: todayDate(), lastActivityTs: Date.now(), inactivityWarning: false, inactivityWarnStartTs: null };
      } else {
        state = { ...state, ...saved, lastActivityTs: Date.now(), inactivityWarning: false, inactivityWarnStartTs: null };
      }
    }
  } catch (e) {
    console.warn('[Therapheye BG] Error loading state:', e);
  }
}

// ─── Activity Detection ───────────────────────────────────────────────────────
// The chrome.idle API detects system-level idle (no keyboard/mouse input anywhere).
// We set the detection threshold to 60 seconds.

function setupIdleDetection() {
  chrome.idle.setDetectionInterval(60); // 60 seconds

  chrome.idle.onStateChanged.addListener((newState) => {
    if (newState === 'active') {
      // User came back from idle
      registerActivity();
    }
    // 'idle' or 'locked' → we let the inactivity timer handle it
  });
}

// Detect navigation/tab activity
function setupTabListeners() {
  // User switched tabs
  chrome.tabs.onActivated.addListener(() => registerActivity());
  // User navigated
  chrome.webNavigation?.onCompleted?.addListener(() => registerActivity());
  // Tab updated (page load, URL change)
  chrome.tabs.onUpdated.addListener((_, changeInfo) => {
    if (changeInfo.status === 'complete' || changeInfo.url) registerActivity();
  });
}

function registerActivity() {
  const wasWarning = state.inactivityWarning;
  state.lastActivityTs = Date.now();
  state.inactivityWarning = false;
  state.inactivityWarnStartTs = null;

  if (wasWarning && state.isRunning) {
    // User came back during warning → dismiss warning, clear notification
    chrome.notifications.clear('therapeye-inactivity');
    broadcastState();
  }
}

// ─── Timer Tick ───────────────────────────────────────────────────────────────

function startTick() {
  if (tickInterval) return;
  tickInterval = setInterval(tick, TICK_INTERVAL_MS);
}

function stopTick() {
  if (tickInterval) {
    clearInterval(tickInterval);
    tickInterval = null;
  }
}

function tick() {
  if (!state.isRunning) return;

  const now = Date.now();
  const elapsed = calcElapsedMs();

  // ── Inactivity check ──
  const inactiveMs = now - state.lastActivityTs;
  const inactiveMin = inactiveMs / 60000;

  if (inactiveMin >= INACTIVITY_MINUTES && !state.inactivityWarning) {
    // Start warning phase
    state.inactivityWarning = true;
    state.inactivityWarnStartTs = now;

    // Show notification
    chrome.notifications.create('therapeye-inactivity', {
      type: 'basic',
      iconUrl: 'icons/icon128.png',
      title: '¿Sigues frente a la pantalla?',
      message: 'No se ha detectado actividad. El temporizador se pausará en 2 minutos si no confirmas.',
      priority: 2,
      requireInteraction: true,
    });

    // Play alert sound via offscreen document
    playAlertSound();
  }

  if (state.inactivityWarning && state.inactivityWarnStartTs) {
    const warnElapsed = (now - state.inactivityWarnStartTs) / 1000;
    if (warnElapsed >= WARN_BEFORE_PAUSE_S) {
      // Auto-pause: user didn't respond in time
      // Subtract the inactivity time (INACTIVITY_MINUTES + WARN_BEFORE_PAUSE_S)
      const totalInactiveMs = (INACTIVITY_MINUTES * 60000) + (WARN_BEFORE_PAUSE_S * 1000);
      const correctedMs = Math.max(0, elapsed - totalInactiveMs);

      state.isRunning = false;
      state.startTimestamp = null;
      state.accumulatedMs = correctedMs;
      state.inactivityWarning = false;
      state.inactivityWarnStartTs = null;

      chrome.notifications.clear('therapeye-inactivity');
      chrome.notifications.create('therapeye-paused', {
        type: 'basic',
        iconUrl: 'icons/icon128.png',
        title: 'Temporizador pausado',
        message: `Se pausó automáticamente por inactividad. Se descontaron ${Math.round(totalInactiveMs / 60000)} minutos.`,
        priority: 1,
      });

      saveState();
      broadcastState();
      stopTick();
      return;
    }
  }

  // ── Break reminder (20-20-20) ──
  if (state.nextBreakAtMs !== null && elapsed >= state.nextBreakAtMs) {
    chrome.notifications.create('therapeye-break-' + Date.now(), {
      type: 'basic',
      iconUrl: 'icons/icon128.png',
      title: '¡Hora de descansar!',
      message: 'Llevas 20 minutos. Mira a 20 pies (6 metros) durante 20 segundos.',
      priority: 2,
    });
    state.nextBreakAtMs = elapsed + WORK_MINUTES * 60000;
  }

  // Update badge
  updateBadge(elapsed);
  broadcastState();

  // Periodic save (every 30s)
  if (Math.floor(Date.now() / 30000) !== Math.floor((Date.now() - 1000) / 30000)) {
    saveState();
  }
}

// ─── Badge ────────────────────────────────────────────────────────────────────

function updateBadge(elapsedMs) {
  const min = Math.floor(elapsedMs / 60000);
  const h = Math.floor(min / 60);
  const m = min % 60;
  const text = h > 0 ? `${h}:${String(m).padStart(2, '0')}` : `${m}m`;

  chrome.action.setBadgeText({ text });
  chrome.action.setBadgeBackgroundColor({
    color: state.inactivityWarning ? '#EF4444' : (state.isRunning ? '#4F46E5' : '#6B7280'),
  });
}

// ─── Sound (via Offscreen API) ────────────────────────────────────────────────

async function playAlertSound() {
  try {
    // Create offscreen document for audio playback
    const contexts = await chrome.runtime.getContexts({
      contextTypes: ['OFFSCREEN_DOCUMENT'],
    });
    if (contexts.length === 0) {
      await chrome.offscreen.createDocument({
        url: 'offscreen.html',
        reasons: ['AUDIO_PLAYBACK'],
        justification: 'Play inactivity alert sound',
      });
    }
    chrome.runtime.sendMessage({ type: 'PLAY_ALERT' });
  } catch (e) {
    console.warn('[Therapheye BG] Error playing sound:', e);
  }
}

// ─── Broadcast state to popup ─────────────────────────────────────────────────

function broadcastState() {
  const elapsed = calcElapsedMs();
  const data = {
    type: 'STATE_UPDATE',
    isRunning: state.isRunning,
    elapsedMs: elapsed,
    formatted: formatDuration(elapsed),
    inactivityWarning: state.inactivityWarning,
    nextBreakAtMs: state.nextBreakAtMs,
    finalized: state.finalized,
  };
  chrome.runtime.sendMessage(data).catch(() => {}); // popup may not be open
}

// ─── Message handler (from popup) ─────────────────────────────────────────────

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === 'GET_STATE') {
    const elapsed = calcElapsedMs();
    sendResponse({
      isRunning: state.isRunning,
      elapsedMs: elapsed,
      formatted: formatDuration(elapsed),
      inactivityWarning: state.inactivityWarning,
      nextBreakAtMs: state.nextBreakAtMs,
      finalized: state.finalized,
    });
    return true;
  }

  if (msg.type === 'START') {
    if (state.isRunning) return;
    const now = Date.now();
    state.isRunning = true;
    state.startTimestamp = now;
    state.sessionStartTimestamp = state.sessionStartTimestamp ?? now;
    state.nextBreakAtMs = state.accumulatedMs + WORK_MINUTES * 60000;
    state.finalized = false;
    state.lastActivityTs = now;
    state.inactivityWarning = false;
    state.stateDate = todayDate();
    saveState();
    startTick();
    broadcastState();
    updateBadge(calcElapsedMs());
  }

  if (msg.type === 'PAUSE') {
    if (!state.isRunning) return;
    state.accumulatedMs = calcElapsedMs();
    state.isRunning = false;
    state.startTimestamp = null;
    state.inactivityWarning = false;
    state.inactivityWarnStartTs = null;
    chrome.notifications.clear('therapeye-inactivity');
    saveState();
    stopTick();
    broadcastState();
    updateBadge(state.accumulatedMs);
  }

  if (msg.type === 'RESET') {
    state.isRunning = false;
    state.startTimestamp = null;
    state.accumulatedMs = 0;
    state.sessionStartTimestamp = null;
    state.nextBreakAtMs = null;
    state.finalized = false;
    state.inactivityWarning = false;
    state.inactivityWarnStartTs = null;
    state.stateDate = todayDate();
    chrome.notifications.clear('therapeye-inactivity');
    saveState();
    stopTick();
    broadcastState();
    updateBadge(0);
  }

  if (msg.type === 'SYNC_FROM_DB') {
    // Popup sends DB state so extension can adopt it
    const dbMs = msg.accumulatedMs || 0;
    const extMs = calcElapsedMs();
    // Use whichever is greater (DB is source of truth on login, but extension
    // may have accumulated more since last DB write)
    if (dbMs > extMs || (!state.isRunning && msg.isRunning)) {
      state.accumulatedMs = dbMs;
      state.isRunning = msg.isRunning || false;
      state.startTimestamp = msg.isRunning ? (msg.startTimestamp || Date.now()) : null;
      state.stateDate = todayDate();
      saveState();
      if (state.isRunning) startTick(); else stopTick();
      broadcastState();
      updateBadge(calcElapsedMs());
    }
    return;
  }

  if (msg.type === 'CONFIRM_ACTIVE') {
    // User confirmed they're still there (from popup or notification click)
    registerActivity();
    broadcastState();
  }

  if (msg.type === 'PLAY_ALERT') {
    // Forwarded to offscreen document — handled there
  }
});

// Handle notification clicks
chrome.notifications.onClicked.addListener((notifId) => {
  if (notifId === 'therapeye-inactivity') {
    registerActivity();
    chrome.notifications.clear('therapeye-inactivity');
    broadcastState();
  }
});

// ─── Initialization ───────────────────────────────────────────────────────────

chrome.runtime.onInstalled.addListener(async () => {
  await loadState();
  setupIdleDetection();
  setupTabListeners();
  if (state.isRunning) startTick();
  updateBadge(calcElapsedMs());
});

chrome.runtime.onStartup.addListener(async () => {
  await loadState();
  setupIdleDetection();
  setupTabListeners();
  if (state.isRunning) startTick();
  updateBadge(calcElapsedMs());
});

// Also setup immediately for when service worker restarts
(async () => {
  await loadState();
  setupIdleDetection();
  setupTabListeners();
  if (state.isRunning) startTick();
  updateBadge(calcElapsedMs());
})();
