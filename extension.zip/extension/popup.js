// ═══════════════════════════════════════════════════════════════════════════════
// Therapheye Extension – Popup Script
// Communicates with background.js, syncs with Neon DB, enforces login.
// ═══════════════════════════════════════════════════════════════════════════════

// ─── Neon DB config ──────────────────────────────────────────────────────────

const NEON_HOST = 'ep-purple-lake-af84yqd7-pooler.c-2.us-west-2.aws.neon.tech';
const NEON_CONN_STRING = 'postgresql://neondb_owner:npg_V7S0FsDyOZtI@ep-purple-lake-af84yqd7-pooler.c-2.us-west-2.aws.neon.tech/neondb?sslmode=require';
const NEON_SQL_URL = `https://${NEON_HOST}/sql`;

const APP_URL = 'https://therapheye.netlify.app';
const APP_URL_LOCAL = 'http://localhost:5173';

// ─── DOM refs ────────────────────────────────────────────────────────────────

const timerTime       = document.getElementById('timerTime');
const timerCircle     = document.getElementById('timerCircle');
const statusDot       = document.getElementById('statusDot');
const btnStart        = document.getElementById('btnStart');
const btnPause        = document.getElementById('btnPause');
const btnReset        = document.getElementById('btnReset');
const warningBanner   = document.getElementById('warningBanner');
const confirmBtnWrap  = document.getElementById('confirmBtnWrap');
const btnConfirmActive = document.getElementById('btnConfirmActive');
const a11yBadge       = document.getElementById('a11yBadge');
const a11yBadgeText   = document.getElementById('a11yBadgeText');
const loginBox        = document.getElementById('loginBox');
const btnOpenLogin    = document.getElementById('btnOpenLogin');
const timerSection    = document.getElementById('timerSection');
const userBar         = document.getElementById('userBar');
const userName        = document.getElementById('userName');
const syncStatus      = document.getElementById('syncStatus');
const openAppLink     = document.getElementById('openAppLink');
const infoSection     = document.getElementById('infoSection');
const confirmOverlay  = document.getElementById('confirmOverlay');
const btnConfirmReset = document.getElementById('btnConfirmReset');
const btnCancelReset  = document.getElementById('btnCancelReset');

let currentUser = null;
let dbConnected = false;

// ─── Neon DB helper ──────────────────────────────────────────────────────────
// Neon Serverless HTTP API: POST /sql with Neon-Connection-String header
// Body: { query, params }
// Response: { fields: [...], rows: [[...], ...], command, rowCount }

async function neonQuery(query, params = []) {
  const res = await fetch(NEON_SQL_URL, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Neon-Connection-String': NEON_CONN_STRING,
    },
    body: JSON.stringify({ query, params }),
  });

  if (!res.ok) {
    const text = await res.text().catch(() => '');
    throw new Error(`Neon HTTP ${res.status}: ${text.slice(0, 200)}`);
  }

  const data = await res.json();
  console.log('[Therapheye DB] Response:', JSON.stringify(data).slice(0, 500));

  // Neon can return rows as arrays [[v1,v2,...]] or as objects [{col:v1,...}]
  // Normalize to always return { rows: [{col: val, ...}], fields, rowCount }
  if (data.fields && data.rows) {
    const fieldNames = data.fields.map(f => f.name);
    const normalizedRows = data.rows.map(row => {
      if (Array.isArray(row)) {
        // Array format: convert to object using field names
        const obj = {};
        fieldNames.forEach((name, i) => { obj[name] = row[i]; });
        return obj;
      }
      // Already object format
      return row;
    });
    return { ...data, rows: normalizedRows };
  }

  // Fallback: wrap results array format
  if (data.results && data.results[0]) {
    return data.results[0];
  }

  return data;
}

function todayDate() {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
}

// ─── DB connection test ──────────────────────────────────────────────────────

async function testDBConnection() {
  try {
    const result = await neonQuery('SELECT 1 as ok');
    if (result.rows && result.rows.length > 0) {
      dbConnected = true;
      setSyncStatus('ok');
      return true;
    }
  } catch (e) {
    console.warn('[Therapheye Popup] DB connection test failed:', e);
  }
  dbConnected = false;
  setSyncStatus('error');
  return false;
}

// ─── DB sync: load timer state from Neon ─────────────────────────────────────

async function loadTimerFromDB(userId) {
  try {
    const result = await neonQuery(
      'SELECT accumulated_ms, is_running, last_start_ts, session_start_ts, next_break_at_ms, finalized FROM timer_state WHERE user_id = $1 AND fecha = $2 LIMIT 1',
      [userId, todayDate()]
    );
    if (result.rows && result.rows.length > 0) {
      const row = result.rows[0];
      dbConnected = true;
      setSyncStatus('ok');
      return {
        accumulatedMs: Number(row.accumulated_ms) || 0,
        isRunning: row.is_running === true || row.is_running === 'true' || row.is_running === 't',
        startTimestamp: row.last_start_ts ? Number(row.last_start_ts) : null,
        sessionStartTimestamp: row.session_start_ts ? Number(row.session_start_ts) : null,
        nextBreakAtMs: row.next_break_at_ms ? Number(row.next_break_at_ms) : null,
        finalized: row.finalized === true || row.finalized === 'true' || row.finalized === 't',
      };
    }
    dbConnected = true;
    setSyncStatus('ok');
    return null; // No data for today yet
  } catch (e) {
    console.warn('[Therapheye Popup] DB load error:', e);
    dbConnected = false;
    setSyncStatus('error');
    return null;
  }
}

async function saveTimerToDB(userId, timerState) {
  if (!dbConnected && !(await testDBConnection())) return; // Skip if no connection
  try {
    await neonQuery(
      `INSERT INTO timer_state (user_id, fecha, accumulated_ms, is_running, last_start_ts, session_start_ts, next_break_at_ms, finalized, updated_at)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, NOW())
       ON CONFLICT (user_id, fecha) DO UPDATE SET
         accumulated_ms = $3, is_running = $4, last_start_ts = $5,
         session_start_ts = $6, next_break_at_ms = $7, finalized = $8, updated_at = NOW()`,
      [
        userId,
        todayDate(),
        Math.round(timerState.accumulatedMs || 0),
        timerState.isRunning || false,
        timerState.startTimestamp ? String(timerState.startTimestamp) : null,
        timerState.sessionStartTimestamp ? String(timerState.sessionStartTimestamp) : null,
        timerState.nextBreakAtMs ? String(timerState.nextBreakAtMs) : null,
        timerState.finalized || false,
      ]
    );
    dbConnected = true;
    setSyncStatus('ok');
  } catch (e) {
    console.warn('[Therapheye Popup] DB save error:', e);
    dbConnected = false;
    setSyncStatus('error');
  }
}

function setSyncStatus(status) {
  if (!syncStatus) return;
  if (status === 'ok') {
    syncStatus.textContent = '● Sincronizado';
    syncStatus.className = 'sync-status';
  } else {
    syncStatus.textContent = '● Sin conexión';
    syncStatus.className = 'sync-status error';
  }
}

// ─── Open Therapheye tab ──────────────────────────────────────────────────────

function openTherapheyeTab() {
  chrome.tabs.query({}, (tabs) => {
    const existing = tabs.find(t =>
      t.url && (t.url.includes('therapheye.netlify.app') || t.url.includes('localhost:5173'))
    );
    if (existing) {
      chrome.tabs.update(existing.id, { active: true });
      chrome.windows.update(existing.windowId, { focused: true });
    } else {
      chrome.tabs.create({ url: APP_URL });
    }
    // Close popup after opening tab
    window.close();
  });
}

// ─── Button event listeners ──────────────────────────────────────────────────

btnStart.addEventListener('click', () => {
  chrome.runtime.sendMessage({ type: 'START' });
  // Sync to DB after a short delay
  if (currentUser) {
    setTimeout(() => {
      chrome.runtime.sendMessage({ type: 'GET_STATE' }, (response) => {
        if (response) {
          saveTimerToDB(currentUser.id, {
            accumulatedMs: response.elapsedMs,
            isRunning: true,
            startTimestamp: Date.now(),
            sessionStartTimestamp: Date.now(),
            nextBreakAtMs: response.nextBreakAtMs,
            finalized: false,
          });
        }
      });
    }, 300);
  }
});

btnPause.addEventListener('click', () => {
  chrome.runtime.sendMessage({ type: 'PAUSE' });
  if (currentUser) {
    setTimeout(() => {
      chrome.runtime.sendMessage({ type: 'GET_STATE' }, (response) => {
        if (response) {
          saveTimerToDB(currentUser.id, {
            accumulatedMs: response.elapsedMs,
            isRunning: false,
            startTimestamp: null,
            sessionStartTimestamp: null,
            nextBreakAtMs: response.nextBreakAtMs,
            finalized: false,
          });
        }
      });
    }, 300);
  }
});

// Reset → show confirmation
btnReset.addEventListener('click', () => {
  confirmOverlay.classList.add('visible');
});

btnConfirmReset.addEventListener('click', () => {
  confirmOverlay.classList.remove('visible');
  chrome.runtime.sendMessage({ type: 'RESET' });
  if (currentUser) {
    saveTimerToDB(currentUser.id, {
      accumulatedMs: 0,
      isRunning: false,
      startTimestamp: null,
      sessionStartTimestamp: null,
      nextBreakAtMs: null,
      finalized: false,
    });
  }
});

btnCancelReset.addEventListener('click', () => {
  confirmOverlay.classList.remove('visible');
});

btnConfirmActive.addEventListener('click', () => {
  chrome.runtime.sendMessage({ type: 'CONFIRM_ACTIVE' });
});

// Timer circle → open therapeye tab
timerCircle.addEventListener('click', (e) => {
  e.stopPropagation();
  openTherapheyeTab();
});

// Login button → open therapeye
btnOpenLogin.addEventListener('click', (e) => {
  e.stopPropagation();
  openTherapheyeTab();
});

// Footer link → open therapeye
openAppLink.addEventListener('click', (e) => {
  e.preventDefault();
  e.stopPropagation();
  openTherapheyeTab();
});

// ─── Accessibility settings ──────────────────────────────────────────────────

function applyAccessibilitySettings(settings) {
  if (!settings) return;

  document.body.classList.toggle('a11y-high-contrast', !!settings.highContrast);
  document.body.classList.toggle('a11y-invert', !!settings.invertColors);

  if (settings.fontSize && settings.fontSize !== 100) {
    document.body.style.setProperty('--popup-font-size', `${Math.round(13 * settings.fontSize / 100)}px`);
  }
  if (settings.fontFamily && settings.fontFamily !== 'default') {
    document.body.style.fontFamily = settings.fontFamily;
  }

  const active = [];
  if (settings.highContrast)  active.push('Alto contraste');
  if (settings.invertColors)  active.push('Colores invertidos');
  if (settings.colorBlindMode && settings.colorBlindMode !== 'none') active.push('Modo daltónico');
  if (settings.fontSize && settings.fontSize !== 100) active.push(`Texto ${settings.fontSize}%`);

  if (active.length > 0) {
    a11yBadgeText.textContent = active.join(' · ');
    a11yBadge.classList.add('visible');
  } else {
    a11yBadge.classList.remove('visible');
  }
}

chrome.storage.local.get('therapeye_a11y_settings', (result) => {
  if (result && result.therapeye_a11y_settings) {
    applyAccessibilitySettings(result.therapeye_a11y_settings);
  }
});

// ─── UI refresh ──────────────────────────────────────────────────────────────

function refreshUI(data) {
  timerTime.textContent = data.formatted || '00:00:00';

  timerCircle.className = 'timer-circle';
  statusDot.className = 'status-dot';

  if (data.inactivityWarning) {
    timerCircle.classList.add('warning');
    statusDot.classList.add('warning');
    warningBanner.style.display = 'block';
    confirmBtnWrap.style.display = 'block';
  } else {
    warningBanner.style.display = 'none';
    confirmBtnWrap.style.display = 'none';
    if (data.isRunning) {
      timerCircle.classList.add('running');
      statusDot.classList.add('running');
    } else {
      statusDot.classList.add('paused');
    }
  }

  if (data.isRunning) {
    btnStart.style.display = 'none';
    btnPause.style.display = 'flex';
  } else {
    btnStart.style.display = 'flex';
    btnPause.style.display = 'none';
  }

  btnReset.disabled = data.elapsedMs === 0;
}

// ─── Login check & initialization ────────────────────────────────────────────

async function initPopup() {
  // Check for user data in chrome.storage
  const stored = await chrome.storage.local.get('therapeye_user');
  const user = stored?.therapeye_user;

  if (user && user.id) {
    currentUser = user;
    showLoggedInUI(user);

    // Test DB connection first
    const connected = await testDBConnection();
    if (connected) {
      await syncFromDB(user.id);
    } else {
      // Still show extension timer even without DB
      chrome.runtime.sendMessage({ type: 'GET_STATE' }, (response) => {
        if (response) refreshUI(response);
      });
    }
  } else {
    showLoginUI();
  }
}

function showLoginUI() {
  loginBox.classList.add('visible');
  timerSection.classList.remove('visible');
  userBar.classList.remove('visible');
  infoSection.style.display = 'none';
}

function showLoggedInUI(user) {
  loginBox.classList.remove('visible');
  timerSection.classList.add('visible');
  userBar.classList.add('visible');
  infoSection.style.display = 'block';
  userName.textContent = user.nombre || user.email;
}

async function syncFromDB(userId) {
  const dbState = await loadTimerFromDB(userId);
  if (dbState && !dbState.finalized) {
    // Send DB state to background to sync the extension timer
    chrome.runtime.sendMessage({
      type: 'SYNC_FROM_DB',
      accumulatedMs: dbState.accumulatedMs,
      isRunning: dbState.isRunning,
      startTimestamp: dbState.startTimestamp,
    });
  }
  // Load current state from background
  setTimeout(() => {
    chrome.runtime.sendMessage({ type: 'GET_STATE' }, (response) => {
      if (response) refreshUI(response);
    });
  }, 100);
}

// ─── Periodic DB sync (every 30s while popup is open) ────────────────────────

setInterval(() => {
  if (currentUser && dbConnected) {
    chrome.runtime.sendMessage({ type: 'GET_STATE' }, (response) => {
      if (response && response.isRunning) {
        saveTimerToDB(currentUser.id, {
          accumulatedMs: response.elapsedMs,
          isRunning: true,
          startTimestamp: Date.now(),
          sessionStartTimestamp: null,
          nextBreakAtMs: response.nextBreakAtMs,
          finalized: false,
        });
      }
    });
  }
}, 30000);

// ─── Listen for state updates from background ────────────────────────────────

chrome.runtime.onMessage.addListener((msg) => {
  if (msg.type === 'STATE_UPDATE') refreshUI(msg);
});

// ─── Refresh timer every second while popup is open ──────────────────────────

setInterval(() => {
  chrome.runtime.sendMessage({ type: 'GET_STATE' }, (response) => {
    if (response) refreshUI(response);
  });
}, 1000);

// ─── Start ───────────────────────────────────────────────────────────────────

initPopup();
