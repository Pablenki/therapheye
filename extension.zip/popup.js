// ═══════════════════════════════════════════════════════════════════════════════
// Therapheye Extension – Popup Script v1.4.0
// ═══════════════════════════════════════════════════════════════════════════════

const NEON_HOST       = 'ep-purple-lake-af84yqd7-pooler.c-2.us-west-2.aws.neon.tech';
const NEON_CONN_STR   = 'postgresql://neondb_owner:npg_V7S0FsDyOZtI@ep-purple-lake-af84yqd7-pooler.c-2.us-west-2.aws.neon.tech/neondb?sslmode=require';
const NEON_SQL_URL    = `https://${NEON_HOST}/sql`;
const APP_URL         = 'https://therapheye.netlify.app';
const APP_URL_LOCAL   = 'http://localhost:5173';

// ─── DOM refs ────────────────────────────────────────────────────────────────

const timerTime        = document.getElementById('timerTime');
const timerCircle      = document.getElementById('timerCircle');
const statusDot        = document.getElementById('statusDot');
const btnStart         = document.getElementById('btnStart');
const btnPause         = document.getElementById('btnPause');
const btnReset         = document.getElementById('btnReset');
const warningBanner    = document.getElementById('warningBanner');
const confirmBtnWrap   = document.getElementById('confirmBtnWrap');
const btnConfirmActive = document.getElementById('btnConfirmActive');
const a11yBadge        = document.getElementById('a11yBadge');
const a11yBadgeText    = document.getElementById('a11yBadgeText');
const btnOpenLogin     = document.getElementById('btnOpenLogin');
const timerSection     = document.getElementById('timerSection');
const userBar          = document.getElementById('userBar');
const userName         = document.getElementById('userName');
const syncStatus       = document.getElementById('syncStatus');
const openAppLink      = document.getElementById('openAppLink');
const infoSection      = document.getElementById('infoSection');
const confirmOverlay   = document.getElementById('confirmOverlay');
const btnConfirmReset  = document.getElementById('btnConfirmReset');
const btnCancelReset   = document.getElementById('btnCancelReset');
const loginHint        = document.getElementById('loginHint');
const foreignBanner    = document.getElementById('foreignBanner');
const foreignTime      = document.getElementById('foreignTime');
const btnTakeOver      = document.getElementById('btnTakeOver');
const btnDismissForeign = document.getElementById('btnDismissForeign');

let currentUser   = null;
let dbConnected   = false;
let foreignDismissed = false;

// ─── Neon DB helper ──────────────────────────────────────────────────────────

async function neonQuery(query, params = []) {
  const res = await fetch(NEON_SQL_URL, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'Neon-Connection-String': NEON_CONN_STR },
    body: JSON.stringify({ query, params }),
  });
  if (!res.ok) {
    const text = await res.text().catch(() => '');
    throw new Error(`Neon HTTP ${res.status}: ${text.slice(0, 200)}`);
  }
  const data = await res.json();
  if (data.fields && data.rows) {
    const fieldNames = data.fields.map(f => f.name);
    const normalizedRows = data.rows.map(row =>
      Array.isArray(row)
        ? Object.fromEntries(fieldNames.map((n, i) => [n, row[i]]))
        : row
    );
    return { ...data, rows: normalizedRows };
  }
  if (data.results?.[0]) return data.results[0];
  return data;
}

function todayDate() {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
}

// ─── DB connection test ──────────────────────────────────────────────────────

async function testDBConnection() {
  try {
    const result = await neonQuery('SELECT 1 as ok');
    if (result.rows?.length > 0) { dbConnected = true; setSyncStatus('ok'); return true; }
  } catch (e) {
    console.warn('[Therapheye Popup] DB connection test failed:', e);
  }
  dbConnected = false;
  setSyncStatus('error');
  return false;
}

// ─── DB sync ─────────────────────────────────────────────────────────────────

async function loadTimerFromDB(userId) {
  try {
    const result = await neonQuery(
      'SELECT accumulated_ms, is_running, last_start_ts, session_start_ts, next_break_at_ms, finalized, source FROM timer_state WHERE user_id = $1 AND fecha = $2 LIMIT 1',
      [userId, todayDate()]
    );
    if (result.rows?.length > 0) {
      const row = result.rows[0];
      dbConnected = true;
      setSyncStatus('ok');
      return {
        accumulatedMs:      Number(row.accumulated_ms) || 0,
        isRunning:          row.is_running === true || row.is_running === 'true' || row.is_running === 't',
        startTimestamp:     row.last_start_ts ? Number(row.last_start_ts) : null,
        sessionStartTimestamp: row.session_start_ts ? Number(row.session_start_ts) : null,
        nextBreakAtMs:      row.next_break_at_ms ? Number(row.next_break_at_ms) : null,
        finalized:          row.finalized === true || row.finalized === 'true' || row.finalized === 't',
        source:             row.source ?? null,
      };
    }
    dbConnected = true;
    setSyncStatus('ok');
    return null;
  } catch (e) {
    console.warn('[Therapheye Popup] DB load error:', e);
    dbConnected = false;
    setSyncStatus('error');
    return null;
  }
}

// Save timer to DB using RAW accumulated_ms + real startTimestamp.
// This avoids double-counting: other clients compute elapsed = accumulated + (now - startTimestamp).
async function saveTimerToDB(userId, accumulatedMs, isRunning, startTimestamp, sessionStartTimestamp, nextBreakAtMs, finalized) {
  if (!dbConnected && !(await testDBConnection())) return;
  try {
    // Get browserId from background
    const { therapeye_browser_id: bid } = await chrome.storage.local.get('therapeye_browser_id');
    const source = bid || null;

    await neonQuery(
      `INSERT INTO timer_state (user_id, fecha, accumulated_ms, is_running, last_start_ts, session_start_ts, next_break_at_ms, finalized, source, updated_at)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, NOW())
       ON CONFLICT (user_id, fecha) DO UPDATE SET
         accumulated_ms = $3, is_running = $4, last_start_ts = $5,
         session_start_ts = $6, next_break_at_ms = $7, finalized = $8,
         source = $9, updated_at = NOW()`,
      [
        userId, todayDate(),
        Math.round(accumulatedMs || 0),
        isRunning || false,
        startTimestamp ? String(startTimestamp) : null,
        sessionStartTimestamp ? String(sessionStartTimestamp) : null,
        nextBreakAtMs ? String(nextBreakAtMs) : null,
        finalized || false,
        source,
      ]
    );
    dbConnected = true;
    setSyncStatus('ok');
  } catch (e) {
    console.warn('[Therapheye Popup] DB save error:', e);
    dbConnected = false;
    setSyncStatus('error');
  }
}

function setSyncStatus(status) {
  if (!syncStatus) return;
  if (status === 'ok') {
    syncStatus.textContent = '● Sincronizado';
    syncStatus.className   = 'sync-status';
  } else {
    syncStatus.textContent = '● Sin conexión';
    syncStatus.className   = 'sync-status error';
  }
}

// ─── Foreign session UI ───────────────────────────────────────────────────────

function showForeignBanner(data) {
  if (!foreignBanner || !foreignTime || foreignDismissed) return;
  const label = data.source?.startsWith('web') ? 'la web' : 'otra extensión';
  foreignTime.textContent = `${data.formatted} en ${label}`;
  foreignBanner.style.display = 'flex';
}

function hideForeignBanner() {
  if (foreignBanner) foreignBanner.style.display = 'none';
}

// ─── Open Therapheye tab ──────────────────────────────────────────────────────

function openTherapheyeTab() {
  chrome.tabs.query({}, (tabs) => {
    const existing = tabs.find(t =>
      t.url && (t.url.includes('therapheye.netlify.app') || t.url.includes('localhost:5173'))
    );
    if (existing) {
      chrome.tabs.update(existing.id, { active: true });
      chrome.windows.update(existing.windowId, { focused: true });
    } else {
      chrome.tabs.create({ url: APP_URL });
    }
    window.close();
  });
}

// ─── Button event listeners ──────────────────────────────────────────────────

btnStart.addEventListener('click', () => {
  chrome.runtime.sendMessage({ type: 'START' });
  if (currentUser) {
    // After START, background has the correct raw accumulatedMs and startTimestamp.
    // Use GET_STATE to retrieve them and save to DB (raw values, no double-counting).
    setTimeout(() => {
      chrome.runtime.sendMessage({ type: 'GET_STATE' }, (response) => {
        if (response) {
          saveTimerToDB(
            currentUser.id,
            response.accumulatedMs,    // raw accumulated (not elapsedMs)
            true,
            response.startTimestamp,   // real start time
            response.startTimestamp,   // session start
            response.nextBreakAtMs,
            false
          );
        }
      });
    }, 300);
  }
});

btnPause.addEventListener('click', () => {
  chrome.runtime.sendMessage({ type: 'PAUSE' });
  if (currentUser) {
    setTimeout(() => {
      chrome.runtime.sendMessage({ type: 'GET_STATE' }, (response) => {
        if (response) {
          // After PAUSE: background has snapped accumulatedMs = total elapsed, startTimestamp = null
          saveTimerToDB(
            currentUser.id,
            response.accumulatedMs,  // accumulated after pause (= total elapsed at pause time)
            false,
            null,
            null,
            response.nextBreakAtMs,
            false
          );
        }
      });
    }, 300);
  }
});

btnReset.addEventListener('click', () => {
  confirmOverlay.classList.add('visible');
});

btnConfirmReset.addEventListener('click', () => {
  confirmOverlay.classList.remove('visible');
  chrome.runtime.sendMessage({ type: 'RESET' });
  if (currentUser) {
    saveTimerToDB(currentUser.id, 0, false, null, null, null, false);
  }
});

btnCancelReset.addEventListener('click', () => {
  confirmOverlay.classList.remove('visible');
});

btnConfirmActive.addEventListener('click', () => {
  chrome.runtime.sendMessage({ type: 'CONFIRM_ACTIVE' });
});

timerCircle.addEventListener('click', (e) => {
  e.stopPropagation();
  openTherapheyeTab();
});

btnOpenLogin.addEventListener('click', (e) => {
  e.stopPropagation();
  openTherapheyeTab();
});

openAppLink.addEventListener('click', (e) => {
  e.preventDefault();
  e.stopPropagation();
  openTherapheyeTab();
});

// ─── Foreign session: Take over / Dismiss ────────────────────────────────────

if (btnTakeOver) {
  btnTakeOver.addEventListener('click', () => {
    hideForeignBanner();
    foreignDismissed = false;
    chrome.runtime.sendMessage({ type: 'TAKE_OVER' });
    // After TAKE_OVER, background snaps to paused state at current elapsed.
    // The user can then press Start to continue from there.
    setTimeout(() => {
      chrome.runtime.sendMessage({ type: 'GET_STATE' }, (response) => {
        if (response) {
          refreshUI(response);
          if (currentUser) {
            saveTimerToDB(
              currentUser.id,
              response.accumulatedMs,
              false, null, null,
              response.nextBreakAtMs, false
            );
          }
        }
      });
    }, 300);
  });
}

if (btnDismissForeign) {
  btnDismissForeign.addEventListener('click', () => {
    hideForeignBanner();
    foreignDismissed = true;
  });
}

// ─── Accessibility settings ──────────────────────────────────────────────────

function applyAccessibilitySettings(settings) {
  if (!settings) return;
  document.body.classList.toggle('a11y-high-contrast', !!settings.highContrast);
  document.body.classList.toggle('a11y-invert', !!settings.invertColors);
  if (settings.fontSize && settings.fontSize !== 100) {
    document.body.style.setProperty('--popup-font-size', `${Math.round(13 * settings.fontSize / 100)}px`);
  }
  if (settings.fontFamily && settings.fontFamily !== 'default') {
    document.body.style.fontFamily = settings.fontFamily;
  }
  const active = [];
  if (settings.highContrast)  active.push('Alto contraste');
  if (settings.invertColors)  active.push('Colores invertidos');
  if (settings.colorBlindMode && settings.colorBlindMode !== 'none') active.push('Modo daltónico');
  if (settings.fontSize && settings.fontSize !== 100) active.push(`Texto ${settings.fontSize}%`);
  if (active.length > 0) {
    a11yBadgeText.textContent = active.join(' · ');
    a11yBadge.classList.add('visible');
  } else {
    a11yBadge.classList.remove('visible');
  }
}

chrome.storage.local.get('therapeye_a11y_settings', (result) => {
  if (result?.therapeye_a11y_settings) {
    applyAccessibilitySettings(result.therapeye_a11y_settings);
  }
});

// ─── UI refresh ───────────────────────────────────────────────────────────────

function refreshUI(data) {
  timerTime.textContent = data.formatted || '00:00:00';
  timerCircle.className = 'timer-circle';
  statusDot.className   = 'status-dot';

  if (data.inactivityWarning) {
    timerCircle.classList.add('warning');
    statusDot.classList.add('warning');
    warningBanner.style.display = 'block';
    confirmBtnWrap.style.display = 'block';
  } else {
    warningBanner.style.display  = 'none';
    confirmBtnWrap.style.display = 'none';
    if (data.isRunning) {
      timerCircle.classList.add('running');
      statusDot.classList.add('running');
    } else {
      statusDot.classList.add('paused');
    }
  }

  if (data.isRunning) {
    btnStart.style.display = 'none';
    btnPause.style.display = 'flex';
  } else {
    btnStart.style.display = 'flex';
    btnPause.style.display = 'none';
  }

  btnReset.disabled = data.elapsedMs === 0;

  // Handle foreign session info from background
  if (data.foreignSession && !foreignDismissed) {
    showForeignBanner(data.foreignSession);
  } else if (!data.foreignSession) {
    hideForeignBanner();
    foreignDismissed = false;
  }
}

// ─── Login check & initialization ────────────────────────────────────────────

async function initPopup() {
  // Load current timer state immediately (works without login)
  chrome.runtime.sendMessage({ type: 'GET_STATE' }, (response) => {
    if (response) refreshUI(response);
  });

  // Check for logged-in user
  const stored = await chrome.storage.local.get('therapeye_user');
  const user   = stored?.therapeye_user;

  if (user?.id) {
    currentUser = user;
    showLoggedInUI(user);
    const connected = await testDBConnection();
    if (connected) await syncFromDB(user.id);
  } else {
    showGuestUI();
  }
}

function showGuestUI() {
  loginHint.classList.add('visible');
  userBar.classList.remove('visible');
}

function showLoggedInUI(user) {
  loginHint.classList.remove('visible');
  userBar.classList.add('visible');
  userName.textContent = user.nombre || user.email;
}

async function syncFromDB(userId) {
  const dbState = await loadTimerFromDB(userId);
  if (dbState && !dbState.finalized) {
    // Send DB state to background for sync.
    // Pass source so background can detect if this is a foreign session.
    chrome.runtime.sendMessage({
      type: 'SYNC_FROM_DB',
      accumulatedMs:  dbState.accumulatedMs,   // raw (not calcElapsed)
      isRunning:      dbState.isRunning,
      startTimestamp: dbState.startTimestamp,  // real start time
      source:         dbState.source,
    });
  }

  // Wait a bit for SYNC_FROM_DB to be processed by background before reading state
  setTimeout(() => {
    chrome.runtime.sendMessage({ type: 'GET_STATE' }, (response) => {
      if (response) refreshUI(response);
    });
  }, 500);
}

// ─── Periodic DB sync (every 30s while popup is open) ────────────────────────
// Uses RAW accumulatedMs + real startTimestamp to avoid double-counting.

setInterval(() => {
  if (currentUser && dbConnected) {
    chrome.runtime.sendMessage({ type: 'GET_STATE' }, (response) => {
      if (response?.isRunning) {
        saveTimerToDB(
          currentUser.id,
          response.accumulatedMs,    // raw accumulated (NOT elapsedMs)
          true,
          response.startTimestamp,   // real start time
          null,
          response.nextBreakAtMs,
          false
        );
      }
    });
  }
}, 30000);

// ─── Listen for state updates from background ────────────────────────────────

chrome.runtime.onMessage.addListener((msg) => {
  if (msg.type === 'STATE_UPDATE') {
    refreshUI(msg);
  }
  if (msg.type === 'RUNNING_ELSEWHERE') {
    if (!foreignDismissed) showForeignBanner(msg);
  }
  if (msg.type === 'FOREIGN_SESSION_CLEARED') {
    hideForeignBanner();
    foreignDismissed = false;
  }
});

// ─── Refresh timer every second while popup is open ──────────────────────────

setInterval(() => {
  chrome.runtime.sendMessage({ type: 'GET_STATE' }, (response) => {
    if (response) refreshUI(response);
  });
}, 1000);

// ─── Start ───────────────────────────────────────────────────────────────────

initPopup();
